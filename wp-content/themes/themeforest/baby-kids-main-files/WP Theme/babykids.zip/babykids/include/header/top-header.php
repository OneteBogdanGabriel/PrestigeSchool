<!--start before navigation-->
<div class="nicdark_section nicdark_bg_greydark nicdark_displaynone_responsive">
    <div class="nicdark_container nicdark_clearfix">
        
        <div class="grid grid_6">
            <div class="nicdark_focus">
                <?php $topheader_left_content = __($redux_demo['topheader_left_content'],'babykids'); ?>
                <?php echo $topheader_left_content; ?>
            </div>
        </div>
        <div class="grid grid_6 right">
            <div class="nicdark_focus right">
                <?php $topheader_right_content = __($redux_demo['topheader_right_content'],'babykids'); ?>
                <?php echo $topheader_right_content; ?>  
            </div>
        </div>

    </div>
</div>
<!--end before navigation-->





